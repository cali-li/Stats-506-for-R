# Midterm Extra Credit for Question 2 Problem C
# Stats 506, Fall 2019
#
# Updated: October 29, 2019
# Author: Cali Li
# Uniqname: lwenjing

# Upload package
library(dplyr)
library(tidyverse)

# Test 1 -----------------------------------------------------------------------
about = function(obj, ...) {
  UseMethod("about")
}

about.default = function(obj) {
  str(obj, give.attr = FALSE)
}

# Test 2 -----------------------------------------------------------------------
about.data.frame = function(obj) {
  n = c()
  l = c()
  c = c()
  i = 0
  while (i < ncol(obj)) {
    i = i + 1
    if (is.numeric(obj[[i]])) {
      n = c(n,colnames(obj)[i])
    } else if (is.list(obj[[i]])) {
      l = c(l,colnames(obj)[i])
    } else if (is.factor(obj[[i]])) {
      c = c(c,colnames(obj)[i])
    }
  }
  cat("\'",class(x)[1],"\': ",nrow(obj)," obs of ",length(obj)," variable(s)",
      "\n",length(n)," numeric column(s): ",paste(n,collapse=","),'\n',
      length(c)," categorical column(s): ",paste(c,collapse=","),'\n',sep='')
}

# Test 3 -----------------------------------------------------------------------
about.tbl = function(obj) {
  NextMethod(obj)
  i = 0
  l = c()
  while (i < ncol(obj)) {
    i = i + 1
    if (is.list(obj[[i]])) {
      l = c(l,colnames(obj)[i])
    }
  }
  cat(length(l)," list column(s): ",paste(l,collapse=","),'\n',sep='')
}
