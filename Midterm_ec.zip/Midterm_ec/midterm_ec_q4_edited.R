# Midterm Extra Credit for Question 4
# Stats 506, Fall 2019
#
# Updated: October 29, 2019
# Author: Cali Li
# Uniqname: lwenjing

# Upload package
library(dplyr)
library(tidyverse)

# Compute average growth rate using pipe
growth_rate = Orange %>%
  add_row(Tree=1,age=0,circumference=0) %>%
  add_row(Tree=2,age=0,circumference=0) %>%
  add_row(Tree=3,age=0,circumference=0) %>%
  add_row(Tree=4,age=0,circumference=0) %>%
  add_row(Tree=5,age=0,circumference=0) %>%
  mutate(factor(Tree)) %>%
  group_by(Tree) %>%
  arrange(age) %>%
  mutate(diff_circum=circumference-lag(circumference,1),
         diff_age=age-lag(age,1),
         growth=diff_circum/diff_age) %>%
  ungroup() %>%
  summarize(average=mean(growth,na.rm=T))